// Surname: Nhlapo
// Name: Nkululeko  Villicent
// Student no: 4129962
// Course: CSC211
// Year: 2023
// Assignment: Practical 2 Term 2
// File: <main.java>


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.PriorityQueue;

public class myMain {

    public static void main(String[] args) {
        // Read in flight data from planes.csv and build the corresponding heap
        PriorityQueue<FlightNode> flightQueue = new PriorityQueue<>();
        try (BufferedReader br = new BufferedReader(new FileReader("planes.csv"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\t");
                String flightNumber = parts[0];
                String departureTimestamp = parts[1] + " " + parts[2];
                String duration = parts[3];

                // Compute arrival date by summing departure time and duration
                Date departure = format(
                        Integer.parseInt(parts[1].split("/")[0]),
                        Integer.parseInt(parts[1].split("/")[1]),
                        Integer.parseInt(parts[1].split("/")[2]),
                        Integer.parseInt(parts[2].split(":")[0]),
                        Integer.parseInt(parts[2].split(":")[1]),
                        Integer.parseInt(parts[2].split(":")[2])
                );
                long durationInSeconds = Integer.parseInt(duration.split(":")[0]) * 3600
                        + Integer.parseInt(duration.split(":")[1]) * 60
                        + Integer.parseInt(duration.split(":")[2]);
                Date arrival = new Date(departure.getTime() + durationInSeconds * 1000);

                FlightNode flight = new FlightNode(flightNumber, arrival);
                flightQueue.add(flight);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Display flights ordered by arrival time
        while (!flightQueue.isEmpty()) {
            System.out.println(flightQueue.poll().toString());
        }
    }

    public static Date format(int day, int month, int year, int hours, int minutes, int seconds) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month - 1, day, hours, minutes, seconds);
        return calendar.getTime();
    }

}
